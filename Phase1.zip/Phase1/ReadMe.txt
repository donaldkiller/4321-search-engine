COMP 4321: Phase 1
Group 20

1. change directory into Phase1
2. javac -cp lib/*:. Phase1.java   (If Phase1.class doesn't exist)  
3. java -cp lib/*:. Phase1

If errors occur, clear out words and URL folders in the db folder, then re-run.